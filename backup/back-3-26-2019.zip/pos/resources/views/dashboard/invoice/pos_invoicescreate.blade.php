@extends('layouts.dashboard')
@section('title','New Invoice')
@section('content')
<!-- Horizontal navigation-->
@include('layouts.inc.success')
<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body"><div class="content-body">
    <div class="card">
        <div class="card-content">
            <div id="notify" class="alert alert-success" style="display:none;">
                <a href="#" class="close" data-dismiss="alert">&times;</a>
                <div class="message"></div>
            </div>
            <div class="card-body">
                    <div class="row">
                        <div class="col-sm-8 cmp-pnl">
                            <div id="customerpanel" class="inner-cmp-pnl">                               
                                <div class="form-group row">
                                    <div class="frmSearch col-sm-12">
                                    <form method="get"" action="{{route('search_customer_pos')}}">
                               
                                        <label for="cst" class="caption">Search Client</label>
                                        <input type="text" class="form-control" name="search"  placeholder="Enter Customer Name or Mobile Number or Email to search"/>
                                        <input type="submit" class="btn btn-success" value="Search">
                                  </form>   
 
                                    </div>
                                </div>
                                <form method="post"" action="{{route('pos_invoices_create_form')}}">
                                @csrf
                                <div id="customer">
                                @php if(isset($posts)) {   @endphp
                                     @foreach($posts as $post)
                                    <div class="clientinfo">
                                         Client Details                                       
                                          <hr>
                                        <input type="hidden" name="billing_name" value="{{$post->billing_name}}">
                                        <div>{{$post->billing_name}}</div>
                                    </div>
                                    <div class="clientinfo">
                                    <input type="hidden" name="billing_address" value="{{$post->billing_address}}">
                                        <div>  {{$post->billing_address}}</div>
                                    </div>
                                    <div class="clientinfo">
                                    <input type="hidden" name="billing_phone" value="{{$post->billing_phone}}">
                                        <div>  {{$post->billing_phone}}</div>
                                    </div>
                                    <div class="clientinfo">
                                    <input type="hidden" name="billing_email" value="{{$post->billing_email}}">
                                        <div>  {{$post->billing_email}}</div>
                                    </div>
                                    <hr>
                                    @endforeach
                                    @php } @endphp  
                                    <div class="users-list-padding media-list">

<br>
<div class="row bg-gradient-directional-purple white m-0 pt-1 pb-1">
    <div class="col-6 ">
        <i class="fa fa-briefcase"></i>
        Products
    </div>
    <div class="col-3">
        <i class="fa fa-money"></i> Price                            </div>
    <div class="col-3">
        <i class="fa fa-shopping-bag"></i> Total                            </div>
</div>
<div id="saman-pos2">
    <div id="pos_items"></div>
</div>
<hr class="mt-1">
<div class="row m-2">
    <div class="col-3">
        <strong>Price Name</strong>
    </div>
    <div class="col-3"><input type="text" name="product_name" placeholder="Product Name" class="form-control">
    </div>
</div>
<div class="row m-2">
    <div class="col-3">
        <strong>  Product Price Total</strong>
    </div>
    <div class="col-6">
    <input type="text" name="total" placeholder="Product Price" class="form-control">
    </div>
</div>
<hr>

<div class="m-1">

    <ul class="nav nav-tabs" role="tablist">
        <li class="nav-item">
            <a class="btn btn-outline-success mb-1" id="base-tab4" data-toggle="tab" aria-controls="tab4" href="#tab4" role="tab" aria-selected="false"><i class="fa fa-cogs"></i>
                POS Properties</a>
        </li>
    </ul>
    <div class="tab-content px-1 pt-1">
        <div class="tab-pane" id="tab1" role="tabpanel" aria-labelledby="base-tab1">
            <input type="hidden" class="text-info" name="i_coupon" id="i_coupon" value="">
            <span class="text-primary text-bold-600" id="r_coupon"></span>
        </div>
        <div class="tab-pane" id="tab4" role="tabpanel" aria-labelledby="base-tab4">
            <div class="form-group row">
                <div class="col-sm-3"><label for="invocieno" class="caption">POS Invoice Number</label>

                    <div class="input-group">
                        <div class="input-group-addon"><span class="icon-file-text-o" aria-hidden="true"></span>
                        </div>
                        <input type="text" class="form-control" placeholder="POS Invoice Number #" name="productnumber" id="invocieno">
                    </div>
                </div>
                <div class="col-sm-3"><label for="invocieno" class="caption">Reference</label>

                    <div class="input-group">
                        <div class="input-group-addon"><span class="icon-bookmark-o" aria-hidden="true"></span>
                        </div>
                        <input type="text" class="form-control" placeholder="Reference #" name="refer">
                    </div>
                </div>


                <div class="col-sm-3"><label for="invociedate" class="caption">POS Date</label>

                    <div class="input-group">
                        <div class="input-group-addon"><span class="icon-calendar4" aria-hidden="true"></span>
                        </div>
                        <input type="date" class="form-control required" placeholder="Billing Date" name="productdate" data-toggle="datepicker" autocomplete="false">
                    </div>
                </div>
                <div class="col-sm-3"><label for="invocieduedate" class="caption">Invoice Due Date</label>

                    <div class="input-group">
                        <div class="input-group-addon"><span class="icon-calendar-o" aria-hidden="true"></span>
                        </div>
                        <input type="date" class="form-control required" id="tsn_due" name="productduedate" placeholder="Due Date" data-toggle="datepicker" autocomplete="false">
                    </div>
                </div>
            </div>


            <div class="form-group row">
                <div class="col-sm-6">
                     Payment Terms <select name="pterms" class="selectpicker form-control"><option value="1">Payment On Receipt</option>
                    </select>
                    Payment Currency for your client                                                                                                                                        <select name="mcurrency" class="selectpicker form-control">
                        <option value="BD">BD</option>
                        
                        </select>                                        </div>
                <div class="col-sm-6">
                    <label for="toAddInfo" class="caption">Invoice Note</label>
                    <textarea class="form-control" name="notes" rows="2"></textarea>
                </div>
            </div>


        </div>
    </div>
</div>


</div>
      <button type="submit" class="btn btn-success " ><i class="fa fa-money"></i> Payment                            </button>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4 cmp-pnl">
                        <div class="title">
                                    <h1>Products</h1> <hr>
                            </div>
                            <div class="inner-cmp-pnl row">
                            @php if(isset($products)){ @endphp
                                @foreach($products as $product)
                                <div class="col-md-3 border">
                                    <div class=" rounded">
                                        <a id="posp1" class="v2_select_pos_item round" data-name="Beer - Sleemans Cream Ale" data-price="386.00" data-tax="12.00" data-discount="3.00" data-pcode="54482-053" data-pid="25" data-stock="123.00" data-unit="">
                                                <img class="round" src="{{asset('uploads/products')}}/{{$product->product_image}}" style="max-height: 100%;max-width: 100%" data-pagespeed-url-hash="1288379604" onload="pagespeed.CriticalImages.checkImageForCriticality(this);">
                                                <div class="text-center" style="margin-top: 4px;">
                                            
                                                    <small style="white-space: pre-wrap;">{{$product->product_name}}</small>
                                                    <small style="white-space: pre-wrap;">{{$product->product_price}}</small>

                                                    
                                                </div></a>
                                        
                                        </div></div>


                                @endforeach
                            {{ $products->links() }}
                            @php } @endphp
                            </div>
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
</div>
</div>
</div>
@endsection