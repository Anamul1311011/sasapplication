<?php /* D:\XAMPP\htdocs\pos\resources\views/dashboard/product/prodectcategory.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!-- Horizontal navigation-->
<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body"><div class="content-body">
    <div class="card">
        <div class="card-header">
            <h5 class="title"> Product Category <a
                        href="<?php echo e(Route('add_product_category')); ?>"
                        class="btn btn-primary btn-sm rounded">
                    Add new                </a>
            </h5>
            <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
            <div class="heading-elements">
                <ul class="list-inline mb-0">
                    <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                    <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                    <li><a data-action="close"><i class="ft-x"></i></a></li>
                </ul>
            </div>
        </div>
        <div class="card-content">
            <div id="notify" class="alert alert-success" style="display:none;">
                <a href="#" class="close" data-dismiss="alert">&times;</a>

                <div class="message"></div>
            </div>
            <div class="card-body">

                <table id="catgtable" class="table table-striped table-bordered zero-configuration">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Total Products</th>
                        <th>Stock Quantity</th>
                        <th>Worth (Sales/Stock)</th>
                        <th> Action</th>


                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                    <td>1</td>
                    <td>General</td>
                    <td>6</td>
                    <td>600</td>
                    <td>$ 236,183.00/$ 109,257.00</td>
                    <td><a href=' productcategory/view?id=1' class='btn btn-success btn-xs'><i class='fa fa-eye'></i> View</a>&nbsp; <a class='btn btn-pink  btn-md' href=' productcategory/report_product?id=1' target='_blank'> <span class='fa fa-pie-chart'></span>Sales</a>&nbsp;  <a href=' productcategory/edit?id=1' class='btn btn-warning btn-xs'><i class='fa fa-pencil'></i> Edit</a>&nbsp;<a href='#' data-object-id='1' class='btn btn-danger btn-xs delete-object' title='Delete'><i class='fa fa-trash'></i></a></td></tr><tr>
                    <td>2</td>
                    <td>Health</td>
                    <td>11</td>
                    <td>587</td>
                    <td>$ 199,839.00/$ 93,586.00</td>
                    <td><a href=' productcategory/view?id=2' class='btn btn-success btn-xs'><i class='fa fa-eye'></i> View</a>&nbsp; <a class='btn btn-pink  btn-md' href=' productcategory/report_product?id=2' target='_blank'> <span class='fa fa-pie-chart'></span>Sales</a>&nbsp;  <a href=' productcategory/edit?id=2' class='btn btn-warning btn-xs'><i class='fa fa-pencil'></i> Edit</a>&nbsp;<a href='#' data-object-id='2' class='btn btn-danger btn-xs delete-object' title='Delete'><i class='fa fa-trash'></i></a></td></tr><tr>
                    <td>3</td>
                    <td>Computers</td>
                    <td>7</td>
                    <td>507</td>
                    <td>$ 200,726.00/$ 96,381.00</td>
                    <td><a href=' productcategory/view?id=3' class='btn btn-success btn-xs'><i class='fa fa-eye'></i> View</a>&nbsp; <a class='btn btn-pink  btn-md' href=' productcategory/report_product?id=3' target='_blank'> <span class='fa fa-pie-chart'></span>Sales</a>&nbsp;  <a href=' productcategory/edit?id=3' class='btn btn-warning btn-xs'><i class='fa fa-pencil'></i> Edit</a>&nbsp;<a href='#' data-object-id='3' class='btn btn-danger btn-xs delete-object' title='Delete'><i class='fa fa-trash'></i></a></td></tr><tr>
                    <td>4</td>
                    <td>Home</td>
                    <td>7</td>
                    <td>733</td>
                    <td>$ 312,414.00/$ 128,460.00</td>
                    <td><a href=' productcategory/view?id=4' class='btn btn-success btn-xs'><i class='fa fa-eye'></i> View</a>&nbsp; <a class='btn btn-pink  btn-md' href=' productcategory/report_product?id=4' target='_blank'> <span class='fa fa-pie-chart'></span>Sales</a>&nbsp;  <a href=' productcategory/edit?id=4' class='btn btn-warning btn-xs'><i class='fa fa-pencil'></i> Edit</a>&nbsp;<a href='#' data-object-id='4' class='btn btn-danger btn-xs delete-object' title='Delete'><i class='fa fa-trash'></i></a></td></tr><tr>
                    <td>5</td>
                    <td>Toys</td>
                    <td>2</td>
                    <td>300</td>
                    <td>$ 131,069.00/$ 61,060.00</td>
                    <td><a href=' productcategory/view?id=5' class='btn btn-success btn-xs'><i class='fa fa-eye'></i> View</a>&nbsp; <a class='btn btn-pink  btn-md' href=' productcategory/report_product?id=5' target='_blank'> <span class='fa fa-pie-chart'></span>Sales</a>&nbsp;  <a href=' productcategory/edit?id=5' class='btn btn-warning btn-xs'><i class='fa fa-pencil'></i> Edit</a>&nbsp;<a href='#' data-object-id='5' class='btn btn-danger btn-xs delete-object' title='Delete'><i class='fa fa-trash'></i></a></td></tr><tr>
                    <td>6</td>
                    <td>Automotive</td>
                    <td>3</td>
                    <td>165</td>
                    <td>$ 76,666.00/$ 27,530.00</td>
                    <td><a href=' productcategory/view?id=6' class='btn btn-success btn-xs'><i class='fa fa-eye'></i> View</a>&nbsp; <a class='btn btn-pink  btn-md' href=' productcategory/report_product?id=6' target='_blank'> <span class='fa fa-pie-chart'></span>Sales</a>&nbsp;  <a href=' productcategory/edit?id=6' class='btn btn-warning btn-xs'><i class='fa fa-pencil'></i> Edit</a>&nbsp;<a href='#' data-object-id='6' class='btn btn-danger btn-xs delete-object' title='Delete'><i class='fa fa-trash'></i></a></td></tr><tr>
                    <td>7</td>
                    <td>Home</td>
                    <td>1</td>
                    <td>131</td>
                    <td>$ 43,492.00/$ 20,305.00</td>
                    <td><a href=' productcategory/view?id=7' class='btn btn-success btn-xs'><i class='fa fa-eye'></i> View</a>&nbsp; <a class='btn btn-pink  btn-md' href=' productcategory/report_product?id=7' target='_blank'> <span class='fa fa-pie-chart'></span>Sales</a>&nbsp;  <a href=' productcategory/edit?id=7' class='btn btn-warning btn-xs'><i class='fa fa-pencil'></i> Edit</a>&nbsp;<a href='#' data-object-id='7' class='btn btn-danger btn-xs delete-object' title='Delete'><i class='fa fa-trash'></i></a></td></tr><tr>
                    <td>8</td>
                    <td>Music</td>
                    <td>9</td>
                    <td>469</td>
                    <td>$ 160,602.00/$ 75,609.00</td>
                    <td><a href=' productcategory/view?id=8' class='btn btn-success btn-xs'><i class='fa fa-eye'></i> View</a>&nbsp; <a class='btn btn-pink  btn-md' href=' productcategory/report_product?id=8' target='_blank'> <span class='fa fa-pie-chart'></span>Sales</a>&nbsp;  <a href=' productcategory/edit?id=8' class='btn btn-warning btn-xs'><i class='fa fa-pencil'></i> Edit</a>&nbsp;<a href='#' data-object-id='8' class='btn btn-danger btn-xs delete-object' title='Delete'><i class='fa fa-trash'></i></a></td></tr><tr>
                    <td>9</td>
                    <td>Tools</td>
                    <td>6</td>
                    <td>786</td>
                    <td>$ 328,243.00/$ 151,870.00</td>
                    <td><a href=' productcategory/view?id=9' class='btn btn-success btn-xs'><i class='fa fa-eye'></i> View</a>&nbsp; <a class='btn btn-pink  btn-md' href=' productcategory/report_product?id=9' target='_blank'> <span class='fa fa-pie-chart'></span>Sales</a>&nbsp;  <a href=' productcategory/edit?id=9' class='btn btn-warning btn-xs'><i class='fa fa-pencil'></i> Edit</a>&nbsp;<a href='#' data-object-id='9' class='btn btn-danger btn-xs delete-object' title='Delete'><i class='fa fa-trash'></i></a></td></tr><tr>
                    <td>10</td>
                    <td>Automotive</td>
                    <td>6</td>
                    <td>569</td>
                    <td>$ 223,809.00/$ 84,744.00</td>
                    <td><a href=' productcategory/view?id=10' class='btn btn-success btn-xs'><i class='fa fa-eye'></i> View</a>&nbsp; <a class='btn btn-pink  btn-md' href=' productcategory/report_product?id=10' target='_blank'> <span class='fa fa-pie-chart'></span>Sales</a>&nbsp;  <a href=' productcategory/edit?id=10' class='btn btn-warning btn-xs'><i class='fa fa-pencil'></i> Edit</a>&nbsp;<a href='#' data-object-id='10' class='btn btn-danger btn-xs delete-object' title='Delete'><i class='fa fa-trash'></i></a></td></tr><tr>
                    <td>11</td>
                    <td>Home</td>
                    <td>1</td>
                    <td>24</td>
                    <td>$ 2,400.00/$ 2,520.00</td>
                    <td><a href=' productcategory/view?id=11' class='btn btn-success btn-xs'><i class='fa fa-eye'></i> View</a>&nbsp; <a class='btn btn-pink  btn-md' href=' productcategory/report_product?id=11' target='_blank'> <span class='fa fa-pie-chart'></span>Sales</a>&nbsp;  <a href=' productcategory/edit?id=11' class='btn btn-warning btn-xs'><i class='fa fa-pencil'></i> Edit</a>&nbsp;<a href='#' data-object-id='11' class='btn btn-danger btn-xs delete-object' title='Delete'><i class='fa fa-trash'></i></a></td></tr><tr>
                    <td>12</td>
                    <td>Shoes</td>
                    <td>7</td>
                    <td>345</td>
                    <td>$ 17,250.00/$ 0.00</td>
                    <td><a href=' productcategory/view?id=12' class='btn btn-success btn-xs'><i class='fa fa-eye'></i> View</a>&nbsp; <a class='btn btn-pink  btn-md' href=' productcategory/report_product?id=12' target='_blank'> <span class='fa fa-pie-chart'></span>Sales</a>&nbsp;  <a href=' productcategory/edit?id=12' class='btn btn-warning btn-xs'><i class='fa fa-pencil'></i> Edit</a>&nbsp;<a href='#' data-object-id='12' class='btn btn-danger btn-xs delete-object' title='Delete'><i class='fa fa-trash'></i></a></td></tr><tr>
                    <td>13</td>
                    <td>جوال</td>
                    <td>1</td>
                    <td>800</td>
                    <td>$ 400,000.00/$ 397,600.00</td>
                    <td><a href=' productcategory/view?id=13' class='btn btn-success btn-xs'><i class='fa fa-eye'></i> View</a>&nbsp; <a class='btn btn-pink  btn-md' href=' productcategory/report_product?id=13' target='_blank'> <span class='fa fa-pie-chart'></span>Sales</a>&nbsp;  <a href=' productcategory/edit?id=13' class='btn btn-warning btn-xs'><i class='fa fa-pencil'></i> Edit</a>&nbsp;<a href='#' data-object-id='13' class='btn btn-danger btn-xs delete-object' title='Delete'><i class='fa fa-trash'></i></a></td></tr>                    </tbody>
                    <tfoot>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Total Products</th>
                        <th>Stock Quantity</th>
                        <th>Worth (Sales/Stock)</th>
                        <th> Action</th>
                    </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        $(document).ready(function () {

            //datatables
            $('#catgtable').DataTable({responsive: true,dom: 'Blfrtip',
                buttons: [
                    {
                        extend: 'excelHtml5',
                        footer: true,
                        exportOptions: {
                            columns: [0,1, 2, 3, 4]
                        }
                    }
                ],});

        });
    </script>
    <div id="delete_model" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">

                    <h4 class="modal-title">Delete</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this product category? <br><strong> It will delete all products in this category also.</strong></strong></p>
                </div>
                <div class="modal-footer">
                    <input type="hidden" id="object-id" value="">
                    <input type="hidden" id="action-url" value="productcategory/delete_i">
                    <button type="button" data-dismiss="modal" class="btn btn-primary"
                            id="delete-confirm">Delete</button>
                    <button type="button" data-dismiss="modal"
                            class="btn">Cancel</button>
                </div>
            </div>
        </div>
    </div></div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>