<?php /* D:\XAMPP\htdocs\pos\resources\views/dashboard/balance/balancesummary.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!-- Horizontal navigation-->
<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body"><div class="content-body">
    <div class="card">
        <div class="card-header">
            <h5>BalanceSheet</h5>
            <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
            <div class="heading-elements">
                <ul class="list-inline mb-0">
                    <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                    <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                    <li><a data-action="close"><i class="ft-x"></i></a></li>
                </ul>
            </div>
        </div>
        <div class="card-content">
            <div id="notify" class="alert alert-success" style="display:none;">
                <a href="#" class="close" data-dismiss="alert">&times;</a>

                <div class="message"></div>
            </div>
            <div class="card-body">

                <h5 class="title bg-gradient-x-info p-1 white">
                    BasicAccounts                </h5>
                <p>&nbsp;</p>
                <table class="table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Account</th>
                        <th>Balance</th>
                    </tr>
                    </thead>
                    <tbody>
                        
                        <?php $__currentLoopData = $Basics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $basic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($basic->name); ?></td>
                                <td><?php echo e($basic->account_no); ?></td>
                                <td><?php echo e($basic->initial_balance); ?> $</td>
                            </tr>      
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
            </tbody>
                    <tfoot>
                    <tr>
                        <th></th>
                        <th></th>

                        <th></th>

                        <th><h3 class="text-xl-left"><?php echo e($Basics->sum('initial_balance')); ?></h3></th>
                    </tr>
                    </tfoot>
                </table>
                <h5 class="title bg-gradient-x-purple p-1 white">
                    AssetsAccounts                </h5>
                <p>&nbsp;</p>
                <table class="table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Account</th>
                        <th>Balance</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $Assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($Asset->name); ?></td>
                                <td><?php echo e($Asset->account_no); ?></td>
                                <td><?php echo e($Asset->initial_balance); ?> $</td>
                            </tr>      
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </tbody>
                    <tfoot>
                    <tr>
                        <th></th>
                        <th></th>

                        <th></th>

                        <th><h3 class="text-xl-left">$ <?php echo e($Assets->sum('initial_balance')); ?></h3></th>
                    </tr>
                    </tfoot>
                </table>

                <h5 class="title bg-gradient-x-danger p-1 white">
                    ExpensesAccounts                </h5>
                <p>&nbsp;</p>
                <table class="table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Account</th>
                        <th>Balance</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $Expensess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Expenses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($Expenses->name); ?></td>
                                <td><?php echo e($Expenses->account_no); ?></td>
                                <td>$ <?php echo e($Expenses->initial_balance); ?></td>
                            </tr>      
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                     </tbody>
                    <tfoot>
                    <tr>
                        <th></th>
                        <th></th>

                        <th></th>

                        <th><h3 class="text-xl-left">$  <?php echo e($Expensess->sum('initial_balance')); ?></h3></th>
                    </tr>
                    </tfoot>
                </table>

                <h5 class="title bg-gradient-x-success p-1 white">
                    IncomeAccounts                </h5>
                <p>&nbsp;</p>
                <table class="table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Account</th>
                        <th>Balance</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $Incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($Income->name); ?></td>
                                <td><?php echo e($Income->account_no); ?></td>
                                <td>$ <?php echo e($Income->initial_balance); ?></td>
                            </tr>      
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </tbody>
                    <tfoot>
                    <tr>
                        <th></th>
                        <th></th>

                        <th></th>

                        <th><h3 class="text-xl-left">$ <?php echo e($Incomes->sum('initial_balance')); ?></h3></th>
                    </tr>
                    </tfoot>
                </table>

                <h5 class="title bg-gradient-x-warning p-1 white">
                    LiabilitiesAccounts                </h5>
                <p>&nbsp;</p>
                <table class="table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Account</th>
                        <th>Balance</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $Liabilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Liabilitie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($Liabilitie->name); ?></td>
                                <td><?php echo e($Liabilitie->account_no); ?></td>
                                <td>$ <?php echo e($Liabilitie->initial_balance); ?></td>
                            </tr>      
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                     </tbody>
                    <tfoot>
                    <tr>
                        <th></th>
                        <th></th>

                        <th></th>

                        <th><h3 class="text-xl-left">$ <?php echo e($Liabilities->sum('initial_balance')); ?></h3></th>
                    </tr>
                    </tfoot>
                </table>

                <h5 class="title bg-gradient-x-grey-blue p-1 white">
                    EquityAccounts                </h5>
                <p>&nbsp;</p>
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Account</th>
                        <th>Balance</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $Equitys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Equity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($Equity->name); ?></td>
                                <td><?php echo e($Equity->account_no); ?></td>
                                <td>$ <?php echo e($Equity->initial_balance); ?></td>
                            </tr>      
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                     </tbody>
                    <tfoot>
                    <tr>
                        <th></th>
                        <th></th>

                        <th></th>

                        <th><h3 class="text-xl-left">$ <?php echo e($Equitys->sum('initial_balance')); ?></h3></th>
                    </tr>
                    </tfoot>
                </table>
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>Type</th>
                        <th>Balance</th>
                    </tr>
                    </thead>
                    <tbody>

                    <tr>
                        <td>Basic</td>
                        <td>$ <?php echo e($Basics->sum('initial_balance')); ?></td>

                    </tr>
                    <tr>
                        <td>Assets</td>
                        <td>$ <?php echo e($Assets->sum('initial_balance')); ?></td>

                    </tr>
                    <tr>
                        <td>Expenses</td>
                        <td>$ <?php echo e($Expensess->sum('initial_balance')); ?></td>

                    </tr>
                    <tr>
                        <td>Income</td>
                        <td>$ <?php echo e($Incomes->sum('initial_balance')); ?></td>

                    </tr>
                    <tr>
                        <td>Liabilities</td>
                        <td>$ <?php echo e($Liabilities->sum('initial_balance')); ?></td>

                    </tr>
                    <tr>
                        <td>Equity</td>
                        <td>$ <?php echo e($Equitys->sum('initial_balance')); ?></td>

                    </tr>
                    </tbody>
                    <tfoot>

                    </tfoot>
                </table>

            </div>
        </div>
    </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>