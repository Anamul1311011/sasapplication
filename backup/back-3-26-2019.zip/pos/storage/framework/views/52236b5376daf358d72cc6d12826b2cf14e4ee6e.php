<?php /* D:\XAMPP\htdocs\pos\resources\views/dashboard/product/editproductcategory.blade.php */ ?>
<?php $__env->startSection('title','Product Category Form'); ?>
<?php $__env->startSection('content'); ?>
<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-header row">
        <?php echo $__env->make('layouts.inc.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="content-body"><article class="content-body">
    <div class="card card-block">
        <div id="notify" class="alert alert-success" style="display:none;">
            <a href="#" class="close" data-dismiss="alert">&times;</a>

            <div class="message"></div>
        </div>
        <div class="card-body">


            <form method="post" action="<?php echo e(Route('edit_product_category_form')); ?>" class="form-horizontal">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <h5>Edit Product Category</h5>
                <hr>

                <div class="form-group row">

                    <label class="col-sm-2 col-form-label"
                           for="product_catname">Category Name</label>

                    <div class="col-sm-6">
                        <input type="text" placeholder="Product Category Name"
                               class="form-control margin-bottom  required" name="product_catname" value="<?php echo e($EditProductCategory->category_name); ?>">
                    </div>
                </div>
                <div class="form-group row">

                    <label class="col-sm-2 col-form-label"
                           for="product_catname">Description</label>

                    <div class="col-sm-6">
                        <input type="text" placeholder="Product Category Short Description"
                               class="form-control margin-bottom required" name="product_catdesc" value="<?php echo e($EditProductCategory->category_description); ?>">
                    </div>
                </div>
                 <input type="hidden" value="0" name="cat_type">
                <div class="form-group row">

                    <label class="col-sm-2 col-form-label"></label>

                    <div class="col-sm-4">
                        <input type="submit" class="btn btn-success margin-bottom"
                               value="Add Category" data-loading-text="Adding...">
                        <input type="hidden" value="<?php echo e($EditProductCategory->id); ?>" name="id"   >
                    </div>
                </div>

            </form>
        </div>
    </div>
</article>

</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>