<?php /* D:\XAMPP\htdocs\pos\resources\views/layouts/inc/horizantalnav.blade.php */ ?>
  <!-- ////////////////////////////////////////////////////////////////////////////-->
    <!-- Horizontal navigation-->
    <div class="header-navbar navbar-expand-sm navbar navbar-horizontal navbar-fixed navbar-light navbar-without-dd-arrow navbar-shadow menu-border"
        role="navigation" data-menu="menu-wrapper">
        <!-- Horizontal menu content-->
        <div class="navbar-container main-menu-content" data-menu="menu-container">

            <ul class="nav navbar-nav" id="main-menu-navigation" data-menu="menu-navigation">
                <li class="nav-item"><a class="nav-link" href="<?php echo e(Route('dashboard')); ?>"><i
                            class="icon-speedometer"></i><span>Dashboard</span></a>

                </li>
                <li class="dropdown nav-item" data-menu="dropdown"><a class="dropdown-toggle nav-link" href="#"
                        data-toggle="dropdown"><i class="icon-basket-loaded"></i><span>Sales</span></a>
                    <ul class="dropdown-menu">
                        <li class="dropdown dropdown-submenu" data-menu="dropdown-submenu"><a
                                class="dropdown-item dropdown-toggle" href="#" data-toggle="dropdown"><i
                                    class="icon-paper-plane"></i>POS Sales</a>
                            <ul class="dropdown-menu">
                                <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('pos_invoices_create')); ?>"
                                        data-toggle="dropdown">New Invoice</a>
                                </li>
                                <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('pos_invoices')); ?>"
                                        data-toggle="dropdown">Manage Invoices</a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown dropdown-submenu" data-menu="dropdown-submenu"><a
                                class="dropdown-item dropdown-toggle" href="#" data-toggle="dropdown"><i
                                    class="icon-basket"></i>Sales</a>
                            <ul class="dropdown-menu">
                                <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('new_invoice')); ?>"
                                        data-toggle="dropdown">New Invoice</a>
                                </li>

                                <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('invoices')); ?>" data-toggle="dropdown">Manage
                                        Invoices</a>
                            </ul>
                        </li>
                        <li class="dropdown dropdown-submenu" data-menu="dropdown-submenu"><a
                                class="dropdown-item dropdown-toggle" href="<?php echo e(Route('quotes')); ?>" data-toggle="dropdown"><i
                                    class="icon-call-out"></i>Quotes</a>
                            <ul class="dropdown-menu">
                                <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('new_quote')); ?>"
                                        data-toggle="dropdown">New Quote</a>
                                </li>

                                <li data-menu=""><a class="dropdown-item" href=" quote" data-toggle="dropdown">Manage
                                        Quotes</a>
                            </ul>
                        </li>

                        <li class="dropdown dropdown-submenu" data-menu="dropdown-submenu"><a
                                class="dropdown-item dropdown-toggle" href="#" data-toggle="dropdown"><i
                                    class="ft-radio"></i>Subscriptions</a>
                            <ul class="dropdown-menu">
                                <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('new_subscription')); ?>"
                                        data-toggle="dropdown">New Subscription</a>
                                </li>

                                <li data-menu=""><a class="dropdown-item" href=" subscriptions"
                                        data-toggle="dropdown">Subscriptions</a>
                            </ul>
                        </li>
                        <li data-menu="">
                            <a class="dropdown-item" href="<?php echo e(Route('credit_notes')); ?>"><i
                                    class="icon-screen-tablet"></i>Credit Notes </a>
                        </li>
                    </ul>
                </li>
                <li class="dropdown nav-item" data-menu="dropdown"><a class="dropdown-toggle nav-link" href="#"
                        data-toggle="dropdown"><i class="ft-layers"></i><span>Stock</span></a>
                    <ul class="dropdown-menu">
                        <li class="dropdown dropdown-submenu" data-menu="dropdown-submenu"><a
                                class="dropdown-item dropdown-toggle" href="#" data-toggle="dropdown"><i
                                    class="ft-list"></i> Items Manager</a>
                            <ul class="dropdown-menu">
                                <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('add_product')); ?>" data-toggle="dropdown">
                                        New Product</a>
                                </li>
                                <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('products')); ?>" data-toggle="dropdown">Manage
                                        Products</a>
                                </li>


                            </ul>
                        </li>
                        <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('product_category')); ?>" data-toggle="dropdown"><i
                                    class="ft-umbrella"></i>Product Categories </a>
                        </li>
                        <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('default_ware_house')); ?>"
                                data-toggle="dropdown"><i class="ft-sliders"></i>Warehouses</a>
                        </li>
                        <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('stock_transfer')); ?>"
                                data-toggle="dropdown"><i class="ft-wind"></i>Stock Transfer</a>
                        </li>
                </li>

                <li class="dropdown dropdown-submenu" data-menu="dropdown-submenu"><a
                        class="dropdown-item dropdown-toggle" href="#" data-toggle="dropdown"><i
                            class="icon-handbag"></i> Purchase Order</a>
                    <ul class="dropdown-menu">
                        <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('new_purches')); ?>" data-toggle="dropdown"> New
                                Order</a>
                        </li>
                        <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('purches')); ?>" data-toggle="dropdown">Manage
                                Orders</a>
                        </li>


                    </ul>
                </li>

                <li class="dropdown dropdown-submenu" data-menu="dropdown-submenu"><a
                        class="dropdown-item dropdown-toggle" href="#" data-toggle="dropdown"><i
                            class="icon-puzzle"></i> Stock Return</a>
                    <ul class="dropdown-menu">
                        <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('supplier_record')); ?>" data-toggle="dropdown"> Suppliers
                                Records</a>
                        </li>
                        <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('customer_record')); ?>"
                                data-toggle="dropdown">Customers Records</a>
                        </li>


                    </ul>
                </li>
                <li class="dropdown dropdown-submenu" data-menu="dropdown-submenu"><a
                        class="dropdown-item dropdown-toggle" href="#" data-toggle="dropdown"><i
                            class="ft-target"></i>Suppliers</a>
                    <ul class="dropdown-menu">
                        <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('create_supplier')); ?>" data-toggle="dropdown">New
                                Supplier</a>
                        </li>

                        <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('supplier')); ?>" data-toggle="dropdown">Manage
                                Suppliers</a>
                    </ul>
                </li>
            </ul>
            </li>
            <li class="dropdown nav-item" data-menu="dropdown"><a class="dropdown-toggle nav-link" href="#"
                    data-toggle="dropdown"><i class="icon-diamond"></i><span>CRM</span></a>
                <ul class="dropdown-menu">
                    <li class="dropdown dropdown-submenu" data-menu="dropdown-submenu"><a
                            class="dropdown-item dropdown-toggle" href="#" data-toggle="dropdown"><i
                                class="ft-users"></i>Clients</a>
                        <ul class="dropdown-menu">
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('create_client')); ?>"
                                    data-toggle="dropdown">New Client</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('clients')); ?>" data-toggle="dropdown">Manage
                                    Clients</a>
                            </li>
                        </ul>
                    </li>
                    <li data-menu="">
                        <a class="dropdown-item" href="<?php echo e(Route('client_group')); ?>"><i class="icon-grid"></i>Client Groups</a>
                    </li>
                    <li class="dropdown dropdown-submenu" data-menu="dropdown-submenu"><a
                            class="dropdown-item dropdown-toggle" href="#" data-toggle="dropdown"><i
                                class="fa fa-ticket"></i>Support Tickets</a>
                        <ul class="dropdown-menu">
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('support_tickets_un_solved')); ?>"
                                    data-toggle="dropdown">UnSolved</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('support_tickets')); ?>" data-toggle="dropdown">Manage
                                    Tickets</a>
                            </li>
                        </ul>
                    </li>

                </ul>
            </li>
            <li class="dropdown nav-item" data-menu="dropdown"><a class="dropdown-toggle nav-link" href="#"
                    data-toggle="dropdown"><i class="icon-briefcase"></i><span>Project</span></a>
                <ul class="dropdown-menu">
                    <li class="dropdown dropdown-submenu" data-menu="dropdown-submenu"><a
                            class="dropdown-item dropdown-toggle" href="#" data-toggle="dropdown"><i
                                class="icon-calendar"></i>Project Management </a>
                        <ul class="dropdown-menu">
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('add_project')); ?>"
                                    data-toggle="dropdown">New Project</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('project_list')); ?>" data-toggle="dropdown">Manage
                                    Projects</a>
                            </li>
                        </ul>
                    </li>
                    <li data-menu="">
                        <a class="dropdown-item" href="<?php echo e(Route('to_do')); ?>"><i class="icon-list"></i>To Do List</a>
                    </li>

                </ul>
            </li>
            <li class="dropdown nav-item" data-menu="dropdown"><a class="dropdown-toggle nav-link" href="#"
                    data-toggle="dropdown"><i class="icon-calculator"></i><span>Accounts</span></a>
                <ul class="dropdown-menu">
                    <li class="dropdown dropdown-submenu" data-menu="dropdown-submenu"><a
                            class="dropdown-item dropdown-toggle" href="#" data-toggle="dropdown"><i
                                class="icon-book-open"></i>Accounts</a>
                        <ul class="dropdown-menu">
                            <li data-menu=""><a class="dropdown-item" href=" <?php echo e(Route('account')); ?>" data-toggle="dropdown">Manage
                                    Accounts</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('balance_summary')); ?>"
                                    data-toggle="dropdown">BalanceSheet</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('account_statement')); ?>"
                                    data-toggle="dropdown">Account Statements</a>
                            </li>
                        </ul>
                    </li>
                    <li class="dropdown dropdown-submenu" data-menu="dropdown-submenu"><a
                            class="dropdown-item dropdown-toggle" href="#" data-toggle="dropdown"><i
                                class="icon-wallet"></i>Transactions</a>
                        <ul class="dropdown-menu">
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('transaction')); ?>" data-toggle="dropdown">View
                                    Transactions</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('add_transaction')); ?>"
                                    data-toggle="dropdown">New Transaction</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('add_transaction')); ?>"
                                    data-toggle="dropdown">New Transfer</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('income_transaction')); ?>"
                                    data-toggle="dropdown">Income</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('expense_transaction')); ?>"
                                    data-toggle="dropdown">Expense</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('customers')); ?>" data-toggle="dropdown">Clients
                                    Transactions</a>
                            </li>
                        </ul>
                    </li>

                </ul>
            </li>

            <li class="dropdown nav-item" data-menu="dropdown"><a class="dropdown-toggle nav-link" href="#"
                    data-toggle="dropdown"><i class="icon-energy"></i><span>Promo Codes</span></a>
                <ul class="dropdown-menu">
                    <li class="dropdown dropdown-submenu" data-menu="dropdown-submenu"><a
                            class="dropdown-item dropdown-toggle" href="#" data-toggle="dropdown"><i
                                class="icon-trophy"></i>Coupons</a>
                        <ul class="dropdown-menu">
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('add_promo')); ?>" data-toggle="dropdown">New
                                    Promo</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('promo')); ?>" data-toggle="dropdown">Manage
                                    Promo</a>
                            </li>
                        </ul>
                    </li>


                </ul>
            </li>

            <li class="dropdown nav-item" data-menu="dropdown"><a class="dropdown-toggle nav-link" href="#"
                    data-toggle="dropdown"><i class="icon-pie-chart"></i><span>Data & Reports</span></a>
                <ul class="dropdown-menu">
                    <li data-menu="">
                        <a class="dropdown-item" href="<?php echo e(Route('register_page')); ?>"><i class="icon-eyeglasses"></i>Business Registers </a>
                    </li>

                    <li class="dropdown dropdown-submenu" data-menu="dropdown-submenu"><a
                            class="dropdown-item dropdown-toggle" href="#" data-toggle="dropdown"><i
                                class="icon-doc"></i>Statements</a>
                        <ul class="dropdown-menu">

                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('account_statement')); ?>"
                                    data-toggle="dropdown">Account Statements</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('cutomer_statement')); ?>"
                                    data-toggle="dropdown">Customer Account Statements</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('supplier_statement')); ?>"
                                    data-toggle="dropdown">Supplier Account Statements</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('tax_statement')); ?>"
                                    data-toggle="dropdown">TAX Statements</a>
                            </li>
                        </ul>
                    </li>

                    <li class="dropdown dropdown-submenu" data-menu="dropdown-submenu"><a
                            class="dropdown-item dropdown-toggle" href="#" data-toggle="dropdown"><i
                                class="icon-bar-chart"></i>Graphical Reports </a>
                        <ul class="dropdown-menu">

                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('product_cat')); ?>"
                                    data-toggle="dropdown">Product Categories</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('trending_products')); ?>"
                                    data-toggle="dropdown">Trending Products</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('profit_reports')); ?>"
                                    data-toggle="dropdown">Profit</a>
                            </li>

                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('customer_report')); ?>" data-toggle="dropdown">
                                    Customers</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('income_vs_expense')); ?>"
                                    data-toggle="dropdown">Income vs Expenses</a>
                            </li>

                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('income_roports')); ?>"
                                    data-toggle="dropdown">Income</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('expense_report')); ?>"
                                    data-toggle="dropdown">Expenses</a>


                        </ul>
                    </li>
                    <li class="dropdown dropdown-submenu" data-menu="dropdown-submenu"><a
                            class="dropdown-item dropdown-toggle" href="#" data-toggle="dropdown"><i
                                class="icon-bulb"></i>Summary & Report </a>
                        <ul class="dropdown-menu">
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('statistics')); ?>"
                                    data-toggle="dropdown">Statistics</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('profit_statement')); ?>"
                                    data-toggle="dropdown">Profit</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('income_statement')); ?>"
                                    data-toggle="dropdown">Calculate Income</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('expense_statement')); ?>"
                                    data-toggle="dropdown">Calculate Expenses</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('sales_statement')); ?>"
                                    data-toggle="dropdown">Sales</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('products_statement')); ?>"
                                    data-toggle="dropdown">Products</a>
                            </li>
                    </li>
                    <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('commission')); ?>" data-toggle="dropdown">Employee
                            Commission</a>
                    </li>

                </ul>
            </li>

            </ul>
            </li>
            <li class="dropdown nav-item" data-menu="dropdown"><a class="dropdown-toggle nav-link" href="#"
                    data-toggle="dropdown"><i class="icon-note"></i><span>Miscellaneous</span></a>
                <ul class="dropdown-menu">
                    <li data-menu="">
                        <a class="dropdown-item" href="<?php echo e(Route('notes')); ?>"><i class="icon-note"></i>Notes</a>
                    </li>
                    <li data-menu="">
                        <a class="dropdown-item" href="<?php echo e(Route('event')); ?>"><i class="icon-calendar"></i>Calendar</a>
                    </li>
                    <li data-menu="">
                        <a class="dropdown-item" href="<?php echo e(Route('document')); ?>"><i class="icon-doc"></i>Documents</a>
                    </li>


                </ul>
            </li>
            <li class="dropdown nav-item" data-menu="dropdown"><a class="dropdown-toggle nav-link" href="#"
                    data-toggle="dropdown"><i class="ft-file-text"></i><span>HRM</span></a>
                <ul class="dropdown-menu">
                    <li class="dropdown dropdown-submenu" data-menu="dropdown-submenu"><a
                            class="dropdown-item dropdown-toggle" href="#" data-toggle="dropdown"><i
                                class="ft-users"></i>Employees</a>
                        <ul class="dropdown-menu">
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('employees_list')); ?>"
                                    data-toggle="dropdown">Employees</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('employee_permission')); ?>"
                                    data-toggle="dropdown">Permissions</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('employees_salaries')); ?>"
                                    data-toggle="dropdown">Salaries</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('attendance')); ?>"
                                    data-toggle="dropdown">Attendance</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="<?php echo e(Route('holidays')); ?>"
                                    data-toggle="dropdown">Holidays</a>
                            </li>
                        </ul>
                    </li>
                    <li data-menu="">
                        <a class="dropdown-item" href="<?php echo e(Route('departments')); ?>"><i class="icon-folder"></i>Departments</a>
                    </li>
                    <li data-menu="">
                        <a class="dropdown-item" href="<?php echo e(Route('employee_payroll_transactions')); ?>"><i class="icon-notebook"></i>Payroll</a>
                    </li>

                </ul>
            </li>
            <li class="dropdown mega-dropdown nav-item" data-menu="megamenu"><a class="dropdown-toggle nav-link"
                    href="#" data-toggle="dropdown"><i class="ft-bar-chart-2"></i><span>Backup &
                        Export-Import</span></a>
                <ul class="mega-dropdown-menu dropdown-menu row">
                    <li class="col-md-4" data-mega-col="col-md-3">
                        <ul class="drilldown-menu">
                            <li class="menu-list">
                                <ul class="mega-menu-sub">
                                    <li><a class="dropdown-item" href="<?php echo e(Route('export_crm_data')); ?>"><i
                                                class="fa fa-caret-right"></i>Export People Data </a>
                                    </li>
                                    <li><a class="dropdown-item" href="<?php echo e(Route('export_transactions')); ?>"><i
                                                class="fa fa-caret-right"></i>Export Transactions </a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(Route('export_products')); ?>"><i
                                                class="fa fa-caret-right"></i>Export Products </a></li>

                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="col-md-4" data-mega-col="col-md-3">
                        <ul class="drilldown-menu">
                            <li class="menu-list">
                                <ul class="mega-menu-sub">
                                    <li><a class="dropdown-item" href="<?php echo e(Route('export_transactions_account')); ?>"><i
                                                class="fa fa-caret-right"></i>Account Statements </a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(Route('tax_statement_export')); ?>"><i
                                                class="fa fa-caret-right"></i>TAX Backup & Export </a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(Route('db_backup')); ?>"><i
                                                class="fa fa-caret-right"></i>Database Backup </a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="col-md-4" data-mega-col="col-md-3">
                        <ul class="drilldown-menu">
                            <li class="menu-list">
                                <ul class="mega-menu-sub">
                                    <li><a class="dropdown-item" href="<?php echo e(Route('import_products')); ?>"><i
                                                class="fa fa-caret-right"></i></i>Import Products </a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(Route('import_procucts_customer')); ?>"><i
                                                class="fa fa-caret-right"></i>Import Customers </a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>

                </ul>
            </li>

            </ul>
        </div>
        <!-- /horizontal menu content-->
    </div>