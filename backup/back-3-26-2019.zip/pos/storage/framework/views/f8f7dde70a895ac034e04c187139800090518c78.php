<?php /* D:\XAMPP\htdocs\pos\resources\views/dashboard/account/addaccount.blade.php */ ?>
<?php $__env->startSection('title','Add Account'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.inc.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Horizontal navigation-->
<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body"><div class="card card-block">
        <div id="notify" class="alert alert-success" style="display:none;">
            <a href="#" class="close" data-dismiss="alert">&times;</a>

            <div class="message"></div>
        </div>
        <div class="card card-block">
            <form action="<?php echo e(Route('add_account_form')); ?>" class="card-body"  method="post" accept-charset="utf-8">
                <?php echo csrf_field(); ?>                                                                                              


            <h5> Add New Account</h5>
            <hr>

            <div class="form-group row">

                <label class="col-sm-2 col-form-label"
                       for="accno">Account No</label>

                <div class="col-sm-6">
                    <input type="text" placeholder="Account Number"
                           class="form-control margin-bottom required" name="accno">
                </div>
            </div>
            <div class="form-group row">

                <label class="col-sm-2 col-form-label" for="holder">Name</label>

                <div class="col-sm-6">
                    <input type="text" placeholder="Name"
                           class="form-control margin-bottom required" name="holder">
                </div>
            </div>

            <div class="form-group row">

                <label class="col-sm-2 col-form-label"
                       for="intbal"> Initial Balance</label>

                <div class="col-sm-6">
                    <input type="number" placeholder="Intial Balance" onkeypress="return isNumber(event)"
                           class="form-control margin-bottom required" name="intbal">
                </div>
            </div>
            <div class="form-group row">

                <label class="col-sm-2 col-form-label" for="acode">Note</label>

                <div class="col-sm-6">
                    <input type="text" placeholder="Note"
                           class="form-control margin-bottom" name="notes">
                </div>
            </div>
            <div class="form-group row">

                <label class="col-sm-2 col-form-label"
                       for="lid">Business Locations</label>

                <div class="col-sm-6">
                <input type="text" placeholder="Add Map link"  class="form-control margin-bottom" name="businesslocation">
                </div>
            </div>
            <div class="form-group row ">

                <label class="col-sm-2 col-form-label"
                       for="account_type">Account Type</label>

                <div class="col-sm-6">
                    <select name="account_type" class="form-control">
                        <option value='Basic'>Default - Basic</option>
                        <option value='Assets'>Assets - Assets</option>
                        <option value='Expenses'>Expenses - Expenses</option>
                        <option value='Income'>Income - Income</option>
                        <option value='Liabilities'>Liabilities - Liabilities</option>
                        <option value='Equity'>Equity - Equity</option>   </select>
                </div>
            </div>
            <div class="form-group row">

                <label class="col-sm-2 col-form-label"></label>

                <div class="col-sm-4">
                    <input type="submit" class="btn btn-success margin-bottom"
                           value="Add Account" data-loading-text="Adding...">
                </div>
            </div>


            </form>
        </div>
    </div></div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>