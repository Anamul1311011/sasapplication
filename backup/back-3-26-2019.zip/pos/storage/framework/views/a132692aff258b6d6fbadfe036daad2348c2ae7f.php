<?php /* D:\XAMPP\htdocs\pos\resources\views/dashboard/addproject.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!-- Horizontal navigation-->
<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body">
<div class="content-body">
    <div class="card">
        <div class="card-header">
            <h5>Add Project</h5>
            <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
            <div class="heading-elements">
                <ul class="list-inline mb-0">
                    <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                    <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                    <li><a data-action="close"><i class="ft-x"></i></a></li>
                </ul>
            </div>
        </div>
        <div class="card-content">
            <div id="notify" class="alert alert-success" style="display:none;">
                <a href="#" class="close" data-dismiss="alert">&times;</a>

                <div class="message"></div>
            </div>
            <div class="card-body">

                <form method="post" id="data_form" class="form-horizontal">

                    <div class="form-group row bg-purple bg-lighten-4 ">

                        <div class="col-md-10"><label class="col col-form-label"
                                                      for="name">Title</label>
                            <input type="text" placeholder="Project Title"
                                   class="form-control mb-1 required" name="name">
                        </div>
                    </div>

                    <div class="form-group row">


                        <div class="col-md-4 bg-blue bg-lighten-4 rounded"><label class="col col-form-label"
                                                                                  for="name">Status</label>
                            <select name="status" class="form-control mb-1">
                                 <option value='Waiting'>Waiting</option>
                            <option value='Pending'>Pending</option>
                            <option value='Terminated'>Terminated</option>
                            <option value='Finished'>Finished</option>
                            <option value='Progress'>Progress</option>                            </select>
                        </div>


                        <div class="col-md-4 border-blue-grey rounded"><label class="col col-form-label"
                                                                              for="progress">Progress                                (in %)</label>
                            <input type="range" min="0" max="100" value="0" class="slider" id="progress"
                                   name="progress">
                            <p><span id="prog"></span></p>

                        </div>


                        <div class="col-md-4 bg-blue bg-lighten-4 rounded"><label class="col col-form-label"
                                                                                  for="pay_cat">Priority</label>
                            <select name="priority" class="form-control mb-1">
                                <option value='Low'>Low</option>
                                <option value='Medium'>Medium</option>
                                <option value='High'>High</option>
                                <option value='Urgent'>Urgent</option>
                            </select>


                        </div>
                    </div>
                    <div class="form-group row">


                        <div class="col-md-4 border-blue-grey rounded"><label class="col col-form-label"
                                                                              for="pay_cat">Customer</label>
                            <select name="customer" class="form-control mb-1" id="customer_statement">
                                <option value="0">Select Customer</option>

                            </select>


                        </div>


                        <div class="col-md-4  rounded bg-blue bg-lighten-4"><label class="col col-form-label"
                                                                                   for="name">Customer Can View</label>
                            <select name="customerview" class="form-control mb-1">
                                <option value='true'>True</option>
                                <option value='false'>False</option>
                            </select>
                        </div>


                        <div class="col-md-4 border-blue rounded">
                            <label class="col col-form-label"
                                   for="name">Customer Can Comment</label>
                            <select name="customercomment" class="form-control mb-1">
                                <option value='true'>True</option>
                                <option value='false'>False</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">


                        <div class="col-md-4 rounded bg-blue bg-lighten-4"><label class="col col-form-label"
                                                                                  for="worth">Budget</label>
                            <input type="number" placeholder="Budget"
                                   class="form-control mb-1  required" name="worth" value="0">
                        </div>

                        <div class="col-md-4 border-blue rounded"><label class="control-label"
                                                                         for="edate">Start Date</label>
                            <input type="text" class="form-control  required"
                                   placeholder="Start Date" name="sdate"
                                   data-toggle="datepicker" autocomplete="false">
                        </div>


                        <div class="col-md-4 rounded bg-blue bg-lighten-4"><label class="control-label"
                                                                                  for="edate">Due Date</label>
                            <input type="text" id="pdate_2" class="form-control  required edate"
                                   placeholder="End Date" name="edate"
                                   autocomplete="false"
                                   value="19-03-2019">
                        </div>


                    </div>


                    <div class="form-group row">


                        <div class="col-md-8 rounded bg-grey-blue bg-lighten-4"><label class="col col-form-label"
                                                                                       for="employee[]">Assign to</label>
                            <select name="employee[]" class="form-control mb-1 required select-box" multiple="multiple">
                                <option value='9'>BusinessOwner</option><option value='16'>Oliver Mammatt</option><option value='17'>Harry McGaughey</option><option value='18'>William Longlands</option><option value='20'>Mark Wales</option><option value='19'>Stephen L. Turner</option>                            </select>


                        </div>


                        <div class="col-md-4   border-blue rounded "><label class="col-form-label"
                                                                            for="phase">Phase</label>
                            <input type="text" placeholder="Phase A,B,C"
                                   class="form-control mb-1  required" name="phase">
                        </div>
                    </div>

                    <div class="form-group row">


                        <div class="col-md-4 border-blue rounded"><label class="col col-form-label"
                                                                         for="name">Link to calendar</label>
                            <select name="link_to_cal" class="form-control mb-1" id="link_to_cal">
                                <option value='0'>No</option>
                                <option value='1'>Mark Deadline(End Date)</option>
                                <option value='2'>Mark Start to End Date</option>
                            </select>
                        </div>


                        <div class="col-md-8 rounded bg-blue bg-lighten-4"><label class="col col-form-label"
                                                                                  for="tags">Tags</label>
                            <input type="text" placeholder="Tags"
                                   class="form-control margin-bottom  required" name="tags">
                        </div>
                    </div>

                    <div id="hidden_div" class="row form-group" style="display: none">
                        <label class="col-md-2 control-label" for="color">Color</label>
                        <div class="col-md-4">
                            <input id="color" name="color" type="text" class="form-control input-md"
                                   readonly="readonly"/>
                            <span class="help-block">Click to pick a color</span>
                        </div>
                    </div>

                    <div class="form-group row">

                        <label class="col-sm-2 control-label"
                               for="content">Note</label>

                        <div class="col-sm-10">
                        <textarea class="summernote"
                                  placeholder=" Note"
                                  autocomplete="false" rows="10" name="content"></textarea>
                        </div>
                    </div>


                    <div class="form-group row">

                        <label class="col-sm-2 col-form-label"
                               for="name">Task Communication</label>

                        <div class="col-sm-4">
                            <select name="ptype" class="form-control">
                                <option value='0'>No</option>
                                <option value='1'>Emails to team</option>
                                <option value='2'>Emails to team, customer</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">

                        <label class="col-sm-2 col-form-label"></label>

                        <div class="col-sm-4">
                            <input type="submit" id="submit-data" class="btn btn-success margin-bottom"
                                   value="Add" data-loading-text="Adding...">
                            <input type="hidden" value="projects/addproject" id="action-url">

                        </div>
                    </div>


                </form>
            </div>
        </div>
    </div>
    </div>
</div>
</div
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>