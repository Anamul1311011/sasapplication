<?php /* D:\XAMPP\htdocs\pos\resources\views/dashboard/projectlist.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!-- Horizontal navigation-->
<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body"><div class="content-body">
    <div class="row">
        <div class="col-xl-3 col-lg-6 col-12">
            <div class="card">
                <div class="card-content">
                    <div class="card-body">
                        <div class="media d-flex">
                            <div class="align-self-center">
                                <i class="fa fa-clock-o primary font-large-2 float-left"></i>
                            </div>
                            <div class="media-body text-right">
                                <h3 class="pink" id="dash_0"></h3>
                                <span>Waiting</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-6 col-12">
            <div class="card">
                <div class="card-content">
                    <div class="card-body">
                        <div class="media d-flex">
                            <div class="align-self-center">
                                <i class="fa fa-exchange warning font-large-2 float-left"></i>
                            </div>
                            <div class="media-body text-right">
                                <h3 class="indigo" id="dash_1"></h3>
                                <span>Progress</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-6 col-12">
            <div class="card">
                <div class="card-content">
                    <div class="card-body">
                        <div class="media d-flex">
                            <div class="align-self-center">
                                <i class="fa fa-flag-checkered success font-large-2 float-left"></i>
                            </div>
                            <div class="media-body text-right">
                                <h3 class="green" id="dash_2"></h3>
                                <span>Finished</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-6 col-12">
            <div class="card">
                <div class="card-content">
                    <div class="card-body">
                        <div class="media d-flex">
                            <div class="align-self-center">
                                <i class="fa fa-dot-circle-o danger font-large-2 float-left"></i>
                            </div>
                            <div class="media-body text-right">
                                <h3 class="deep-cyan" id="dash_6">1</h3>
                                <span>Total</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-header">
            <h3 class="title">
                Projects <a href=" projects/addproject"
                                                               class="btn btn-primary btn-sm rounded">
                    Add new                </a>
            </h3>
            <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
            <div class="heading-elements">
                <ul class="list-inline mb-0">
                    <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                    <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                    <li><a data-action="close"><i class="ft-x"></i></a></li>
                </ul>
            </div>
        </div>
        <div class="card-content">
            <div id="notify" class="alert alert-success" style="display:none;">
                <a href="#" class="close" data-dismiss="alert">&times;</a>

                <div class="message"></div>
            </div>
            <div class="card-body">

                <table id="ptable" class="table table-striped table-bordered zero-configuration" cellspacing="0"
                       width="100%">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Project</th>
                        <th>Due Date</th>
                        <th>Customer</th>
                        <th>Status</th>

                        <th>Actions</th>


                    </tr>
                    </thead>
                    <tbody>

                    </tbody>

                </table>
            </div>
        </div>
        <input type="hidden" id="dashurl" value="projects/projects_stats">
    </div>

    <div id="delete_model" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Delete</h4>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this project and related content? </p>
                </div>
                <div class="modal-footer">
                    <input type="hidden" id="object-id" value="">
                    <input type="hidden" id="action-url" value="projects/delete_i">
                    <button type="button" data-dismiss="modal" class="btn btn-primary"
                            id="delete-confirm">Delete</button>
                    <button type="button" data-dismiss="modal"
                            class="btn">Cancel</button>
                </div>
            </div>
        </div>
    </div>
    <div id="pop_model" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Change Status</h4>
                </div>

                <div class="modal-body">
                    <form id="form_model">


                        <div class="row">
                            <div class="col-xs-12 mb-1"><label
                                        for="status">Change Status</label>
                                <select name="stat" class="form-control mb-1">
                                    <option value="Due">Due</option>
                                    <option value="Progress">Progress</option>
                                    <option value="Done">Done</option>
                                </select>

                            </div>
                        </div>

                        <div class="modal-footer">
                            <input type="hidden" class="form-control"
                                   name="tid" id="taskid" value="">
                            <button type="button" class="btn btn-default"
                                    data-dismiss="modal"> Close</button>
                            <input type="hidden" id="action-url" value="tools/set_task">
                            <button type="button" class="btn btn-primary"
                                    id="submit_model">Change Status</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div id="task_model" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="task_title">Details</h4>
                </div>

                <div class="modal-body">
                    <form id="form_model">


                        <div class="row">
                            <div class="col-xs-12 mb-1" id="description">

                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-xs-12 mb-1">Priority <strong><span
                                            id="priority"></span></strong>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 mb-1">Assigned to <strong><span
                                            id="employee"></span></strong>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 mb-1">Assigned by <strong><span
                                            id="assign"></span></strong>

                            </div>
                        </div>

                        <div class="modal-footer">
                            <input type="hidden" class="form-control required"
                                   name="tid" id="taskid" value="">
                            <button type="button" class="btn btn-default"
                                    data-dismiss="modal"> Close</button>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">

        $(document).ready(function () {

            $('#ptable').DataTable({

                "processing": true,
                "serverSide": true,
                "stateSave": true,
                responsive: true,
                "order": [[2, "asc"]],
                "ajax": {
                    "url": " projects/project_load_list",
                    "type": "POST",
                    'data': {'g_ea0d': crsf_hash, 'eid':0}
                },
                "columnDefs": [
                    {
                        "targets": [0],
                        "orderable": true,
                    },
                ],dom: 'Blfrtip',
                buttons: [
                    {
                        extend: 'excelHtml5',
                        footer: true,
                        exportOptions: {
                            columns: [0,1,2, 3,4]
                        }
                    }
                ],

            });

            $(document).on('click', ".set-task", function (e) {
                e.preventDefault();
                $('#taskid').val($(this).attr('data-id'));
                $('#pop_model').modal({backdrop: 'static', keyboard: false});

            });


            $(document).on('click', ".view_task", function (e) {
                e.preventDefault();

                var actionurl = 'projects/view_project';
                var id = $(this).attr('data-id');
                $('#task_model').modal({backdrop: 'static', keyboard: false});


                $.ajax({

                    url: baseurl + actionurl,
                    type: 'POST',
                    data: {'tid': id},
                    dataType: 'json',
                    success: function (data) {

                        $('#description').html(data.description);
                        $('#task_title').html(data.name);
                        $('#employee').html(data.employee);
                        $('#assign').html(data.assign);
                        $('#priority').html(data.priority);
                    }

                });

            });
            miniDash();


        });

    </script></div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>