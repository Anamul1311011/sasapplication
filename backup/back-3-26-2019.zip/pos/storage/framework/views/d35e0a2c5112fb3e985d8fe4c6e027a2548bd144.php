<?php /* D:\XAMPP\htdocs\pos\resources\views/dashboard/attendance/adminattendance.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!-- Horizontal navigation-->
<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-header row">
        </div>
<div class="content">
    <div class="card card-block">
        <div class="card-body">
            <!-- Notification -->
            <div class="alert"></div>


            <div id='adate'></div>
        </div>
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>