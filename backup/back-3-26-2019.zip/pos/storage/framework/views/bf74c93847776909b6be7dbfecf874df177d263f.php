<?php /* D:\XAMPP\htdocs\pos\resources\views/dashboard/employee/employeeslistadd.blade.php */ ?>
<?php $__env->startSection('title','Employee Add'); ?>
<?php $__env->startSection('content'); ?>
<!-- Horizontal navigation-->
<?php if(Auth::User()->user_role == 1): ?>
<?php echo $__env->make('layouts.inc.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body"><div class="content-body">

            <div class="card card-block bg-white">
                <div id="notify" class="alert alert-success" style="display:none;">
                    <a href="#" class="close" data-dismiss="alert">&times;</a>

                    <div class="message"></div>
                </div>
                <form method="post" action="<?php echo e(Route('add_employees_list_form')); ?>" class="card-body">
                    <?php echo csrf_field(); ?>

                    <h5>Employee Details </h5>
                    <hr>
                    <div class="form-group row">

                        <label class="col-sm-6 col-form-label"
                               for="name">UserName <small class="error">(Use Only a-z0-9)</small>
                        </label>

                        <div class="col-sm-10">
                            <input type="text"
                                   class="form-control margin-bottom required" name="username"
                                   placeholder="username">
                        </div>
                    </div>

                    <div class="form-group row">

                        <label class="col-sm-6 col-form-label" for="email">Email</label>

                        <div class="col-sm-10">
                            <input type="email" placeholder="email"
                                   class="form-control margin-bottom required" name="email"
                                   placeholder="email">
                        </div>
                    </div>
                    <div class="form-group row">

                        <label class="col-sm-6 col-form-label"
                               for="password">                            <small>(min length 6 | max length 20 | a-zA-Z 0-9 @ $)</small>
                        </label>

                        <div class="col-sm-10">
                            <input type="text" placeholder="Password"
                                   class="form-control margin-bottom required" name="password"
                                   placeholder="password">
                        </div>
                    </div>
                                            <div class="form-group row">

                            <label class="col-sm-2 col-form-label"
                                   for="name">UserRole</label>

                            <div class="col-sm-5">
                                <select name="roleid" class="form-control margin-bottom">
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($role->id); ?>"><?php echo e($role->role_name); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>


                    
                    <div class="form-group row">

                        <label class="col-sm-2 col-form-label"
                               for="name">Business Location</label>

                        <div class="col-sm-5">
                            <select name="location" class="form-control margin-bottom">
                                <option value="0">Default</option>
                                                            </select>
                        </div>
                    </div>

                    <hr>

                    <div class="form-group row">

                        <label class="col-sm-2 col-form-label"
                               for="name">Name</label>

                        <div class="col-sm-10">
                            <input type="text" placeholder="Name"
                                   class="form-control margin-bottom required" name="name"
                                   placeholder="Full name">
                        </div>
                    </div>
                    <div class="form-group row">

                        <label class="col-sm-2 col-form-label"
                               for="address"> Address</label>

                        <div class="col-sm-10">
                            <input type="text" placeholder="address"
                                   class="form-control margin-bottom" name="address">
                        </div>
                    </div>
                    <div class="form-group row">

                        <label class="col-sm-2 col-form-label"
                               for="city">City</label>

                        <div class="col-sm-10">
                            <input type="text" placeholder="City"
                                   class="form-control margin-bottom" name="city">
                        </div>
                    </div>
                    <div class="form-group row">

                        <label class="col-sm-2 col-form-label"
                               for="city">Region</label>

                        <div class="col-sm-10">
                            <input type="text" placeholder="Region"
                                   class="form-control margin-bottom" name="region">
                        </div>
                    </div>
                    <div class="form-group row">

                        <label class="col-sm-2 col-form-label"
                               for="country">Country</label>

                        <div class="col-sm-10">
                            <input type="text" placeholder="Country"
                                   class="form-control margin-bottom" name="country">
                        </div>
                    </div>

                    <div class="form-group row">

                        <label class="col-sm-2 col-form-label"
                               for="postbox"></label>

                        <div class="col-sm-10">
                            <input type="text" placeholder="Postbox"
                                   class="form-control margin-bottom" name="postbox">
                        </div>
                    </div>
                    <div class="form-group row">

                        <label class="col-sm-2 col-form-label"
                               for="phone"> Phone</label>

                        <div class="col-sm-10">
                            <input type="text" placeholder="phone"
                                   class="form-control margin-bottom" name="phone">
                        </div>
                    </div>
                    <div class="form-group row">

                        <label class="col-sm-2 col-form-label"
                               for="phone">Salary</label>

                        <div class="col-sm-5">
                            <input type="text" placeholder="Salary" onkeypress="return isNumber(event)"
                                   class="form-control margin-bottom" name="salary"
                                   value="0">
                        </div>
                    </div>
                    <div class="form-group row">

                        <label class="col-sm-2 col-form-label"
                               for="city">Sales Commission                            %</label>

                        <div class="col-sm-2">
                            <input type="number" placeholder="Commission %" value="0"
                                   class="form-control margin-bottom" name="commission">
                        </div>
                        <small class="col">It will based on each invoice amount - inclusive all
                            taxes,shipping,discounts
                        </small>

                    </div>
                                      <div class="form-group row">

                                <label class="col-sm-2 col-form-label"
                                       for="name">Department</label>

                                <div class="col-sm-5">
                                    <select name="department" class="form-control margin-bottom">
                                        <option value="0">Default - No</option>
                                        <option value="1"> General</option> <option value="2"> Sales</option> <option value="3"> Food</option> <option value="5"> Human Resource</option>                                    </select>
                                </div>
                            </div>

                    <div class="form-group row">

                        <label class="col-sm-2 col-form-label"></label>

                        <div class="col-sm-4">
                            <input type="submit" class="btn btn-success margin-bottom"
                                   value="Add"
                                   data-loading-text="Adding...">
                        </div>
                    </div>


                </form>
            </div>

    </div>
    <?php else: ?>
    <div class="col">
      <div class="alert alert-success">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">
               <span aria-hidden="true">&times;</span>
        </button>
         <strong>You have no permission for view this page</strong> 
    </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>