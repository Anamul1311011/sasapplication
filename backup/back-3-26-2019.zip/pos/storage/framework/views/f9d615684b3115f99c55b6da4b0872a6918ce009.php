<?php /* D:\XAMPP\htdocs\pos\resources\views/dashboard/employeeslist.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!-- Horizontal navigation-->
<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body"><div class="content-body">
    <div class="card">
        <div class="card-header">
            <h5 class="title">
                Employee <a href=" employee/add"
                                                               class="btn btn-primary btn-sm rounded">
                    Add new                </a>
            </h5>
            <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
            <div class="heading-elements">
                <ul class="list-inline mb-0">
                    <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                    <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                    <li><a data-action="close"><i class="ft-x"></i></a></li>
                </ul>
            </div>
        </div>
        <div class="card-content">
            <div id="notify" class="alert alert-success" style="display:none;">
                <a href="#" class="close" data-dismiss="alert">&times;</a>

                <div class="message"></div>
            </div>
            <div class="card-body">


                <table id="emptable" class="table table-striped table-bordered zero-configuration" cellspacing="0"
                       width="100%">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Actions</th>


                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                    <td>1</td>
                    <td>BusinessOwner</td>
                    <td>Business Owner</td>                 
                    <td>Active</td>
                    <td><a href=' employee/view?id=9' class='btn btn-success btn-xs'><i class='fa fa-eye'></i> View</a>&nbsp;&nbsp;<a href='#' data-object-id='9' class='btn btn-amber btn-xs delete-object' title='Disable'><i class='fa fa-chain-broken'></i> Disable</a>&nbsp;&nbsp;<a href='#pop_model' data-toggle='modal' data-remote='false' data-object-id='9' class='btn btn-danger btn-xs delemp' title='Delete'><i class='fa fa-trash'></i></a></td></tr><tr>
                    <td>2</td>
                    <td>Oliver Mammatt</td>
                    <td>Business Manager</td>                 
                    <td>Active</td>
                    <td><a href=' employee/view?id=16' class='btn btn-success btn-xs'><i class='fa fa-eye'></i> View</a>&nbsp;&nbsp;<a href='#' data-object-id='16' class='btn btn-amber btn-xs delete-object' title='Disable'><i class='fa fa-chain-broken'></i> Disable</a>&nbsp;&nbsp;<a href='#pop_model' data-toggle='modal' data-remote='false' data-object-id='16' class='btn btn-danger btn-xs delemp' title='Delete'><i class='fa fa-trash'></i></a></td></tr><tr>
                    <td>3</td>
                    <td>Harry McGaughey</td>
                    <td>Sales Manager</td>                 
                    <td>Active</td>
                    <td><a href=' employee/view?id=17' class='btn btn-success btn-xs'><i class='fa fa-eye'></i> View</a>&nbsp;&nbsp;<a href='#' data-object-id='17' class='btn btn-amber btn-xs delete-object' title='Disable'><i class='fa fa-chain-broken'></i> Disable</a>&nbsp;&nbsp;<a href='#pop_model' data-toggle='modal' data-remote='false' data-object-id='17' class='btn btn-danger btn-xs delemp' title='Delete'><i class='fa fa-trash'></i></a></td></tr><tr>
                    <td>4</td>
                    <td>William Longlands</td>
                    <td>Sales Person</td>                 
                    <td>Active</td>
                    <td><a href=' employee/view?id=18' class='btn btn-success btn-xs'><i class='fa fa-eye'></i> View</a>&nbsp;&nbsp;<a href='#' data-object-id='18' class='btn btn-amber btn-xs delete-object' title='Disable'><i class='fa fa-chain-broken'></i> Disable</a>&nbsp;&nbsp;<a href='#pop_model' data-toggle='modal' data-remote='false' data-object-id='18' class='btn btn-danger btn-xs delemp' title='Delete'><i class='fa fa-trash'></i></a></td></tr><tr>
                    <td>5</td>
                    <td>Mark Wales</td>
                    <td>Inventory Manager</td>                 
                    <td>Active</td>
                    <td><a href=' employee/view?id=20' class='btn btn-success btn-xs'><i class='fa fa-eye'></i> View</a>&nbsp;&nbsp;<a href='#' data-object-id='20' class='btn btn-amber btn-xs delete-object' title='Disable'><i class='fa fa-chain-broken'></i> Disable</a>&nbsp;&nbsp;<a href='#pop_model' data-toggle='modal' data-remote='false' data-object-id='20' class='btn btn-danger btn-xs delemp' title='Delete'><i class='fa fa-trash'></i></a></td></tr><tr>
                    <td>6</td>
                    <td>Stephen L. Turner</td>
                    <td>Project Manager</td>                 
                    <td>Active</td>
                    <td><a href=' employee/view?id=19' class='btn btn-success btn-xs'><i class='fa fa-eye'></i> View</a>&nbsp;&nbsp;<a href='#' data-object-id='19' class='btn btn-amber btn-xs delete-object' title='Disable'><i class='fa fa-chain-broken'></i> Disable</a>&nbsp;&nbsp;<a href='#pop_model' data-toggle='modal' data-remote='false' data-object-id='19' class='btn btn-danger btn-xs delemp' title='Delete'><i class='fa fa-trash'></i></a></td></tr>                    </tbody>
                    <tfoot>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        $(document).ready(function () {

            //datatables
            $('#emptable').DataTable({responsive: true,dom: 'Blfrtip',
                buttons: [
                    {
                        extend: 'excelHtml5',
                        footer: true,
                        exportOptions: {
                            columns: [0,1,2,3]
                        }
                    }
                ],});


        });

        $('.delemp').click(function (e) {
            e.preventDefault();
            $('#empid').val($(this).attr('data-object-id'));

        });
    </script>


    <div id="delete_model" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">

                    <h4 class="modal-title">Deactive Employee</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to deactivate this account ? <br><strong> It will disable this account
                            access
                            to
                            user.</strong></p>
                </div>
                <div class="modal-footer">
                    <input type="hidden" id="object-id" value="">
                    <input type="hidden" id="action-url" value="employee/disable_user">
                    <button type="button" data-dismiss="modal" class="btn btn-primary" id="delete-confirm">Confirm
                    </button>
                    <button type="button" data-dismiss="modal" class="btn">Cancel</button>
                </div>
            </div>
        </div>
    </div>

    <div id="pop_model" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">

                    <h4 class="modal-title">Delete</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>

                <div class="modal-body">
                    <form id="form_model">


                        <div class="modal-body">
                            <p>Are you sure you want to delete this employee? <br><strong> It may interrupt old
                                    invoices,
                                    disable account is a better option.</strong></p>
                        </div>
                        <div class="modal-footer">


                            <input type="hidden" class="form-control required"
                                   name="empid" id="empid" value="">
                            <button type="button" class="btn btn-default"
                                    data-dismiss="modal"> Close</button>
                            <input type="hidden" id="action-url" value="employee/delete_user">
                            <button type="button" class="btn btn-primary"
                                    id="submit_model">Delete</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div></div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>